# 파이썬 빅데이터 프로그래밍 기말고사 정리

> 쉬운 문제들이긴 했는데 그래도 복습 ㅎㅎ



### 1) 튜플(tuple)은 생성, 삭제, 수정 가능

\>> X		(리스트는 그 값의 생성, 삭제, 수정이 가능하지만 튜플은 그 값을 바꿀 수 없음)



### 2) v1 = 'abcde'에서 v1.isupper()를 사용하면 대문자로 치환

\>> X 		(대문자로 치환할 때는 upper / 대소문자인지 확인할 때는 isupper)



### 3) next()함수는 첫 번째 데이터 행 읽어오면서 데이터 탐색 위치를 다음 행으로 이동

\>> O



### 4) vname = 'multi-campus'에서 이름의 두 번째 글자가 m인지 여부 확인하는 코드

\>> vname[1] == 'm'



### 5) 반복제어문에 대한 잘못된 설명

\>> continue : 특정 조건일 경우 반복문 건너뛰기

\>> break : 특정 조건일 경우 반복문 종료

\>> exit : 특정 조건일 경우 프로그램 종료

\>> pass : 문법적으로 오류 발생시키지 않게 하기 위해 자리 채우기



### 6) 데이터 시각화하는 코드 중 잘못된 것

\>> plt.scatter(x, y, kind = 'kde')		(scatter plot은 산점도, kind = kde는 커널 밀도 함수)



### 7) 함수 선언 시 사용하는 예약어

\>> def



### 8) 연도별, 제품별 판매금액의 총 합을 교차표로

\>> df.pivot_table(index  = '판매년도', columns = '제품', values = '판매금액', aggfunc = 'sum')



### 9) 









import pandas as pd
import numpy as np

sample_1 = pd.read_excel('./files/sample_1.xlsx',
                        header = 1,
                        usecols = 'A:C',
                        skipfooter = 2,
                        names = ['A', 'B','C'])
sample_1