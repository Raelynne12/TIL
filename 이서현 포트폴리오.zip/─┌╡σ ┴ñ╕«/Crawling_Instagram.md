# 인스타그램 크롤링(가장 뜨는 제주도 맛집은 어딜까?)

> 인스타그램을 크롤링해서 제주도맛집 정보를 가져온 후
>
> 해시태그별 언급수 등을 파악하고 barplot과 wordcloud로 나타내기



```python
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from bs4 import BeautifulSoup
import pandas as pd
import numpy as np
import time
```

```python
service = Service('../chromedriver.exe')
driver = webdriver.Chrome(service = service)
url = 'https://www.instagram.com'
driver.get(url)
time.sleep(3)
```

```python
#검색할 태그써서 경로찾는 함수
def insta_searching(word):
    url = 'https://www/instagram.com/explore/tags/' + word  #이렇게 써도 됨
    return url  #이 함수를 호출하면 url이 나오게
```

```python
#제주도맛집이라고 치고 한 번 해보기
word  = '제주도맛집'
driver.get(insta_searching(word))
time.sleep(5)
```

```python
from selenium.webdriver.common.bt import By

#여러 게시물들 중 첫 번째 게시물 클릭하게 하는 함수
def select_first(driver):
    first = driver.find_element(By.CSS_SELECTOR, 'div_9AhH0') #html 안에서 움직이게 도와줌
    first.click()
    time.sleep(3)
select_first(driver)
```

```python
#데리고 올 내용 : 본문 내용, 해시태그, 작성일자, 좋아요수, 위치정보
html = driver.page_source
soup = BeautifulSoup(html, 'html.parser')

#본문 내용
content = soup.select('div.C4VMK > span')[0].text 
content  #하면 본문 내용 나옴

#해시태그
import re
tags = re.findall(r'#\w+', content) #본문 내용에서 하나 이상되는 문자들 뽑아라#
tags = re.findall(r'#[^\s#,\\]+', content) #위에 + ^\/이런 거 없으면 나오게 하는 [] : or
tags #하면 해시태그들 나옴

#작성일자
date = soup.select('time._1o9PC.Nzb55')[0]['datetime'][:10] #데이트타임 속 10전까지
date #하면 작성일자 나옴

#좋아요수
like = soup.select('a.zV_Nj > span')[0].text
like #하면 좋아요수 나옴

#위치정보
place = soup.select('div > a.O4GIU')[0].text
place #하면 위치정보 나옴
```

```python
#위의 해본 내용들을 함수에 넣어보기
def get_content(driver):
    html = driver.page_source
    soup = BeautifulSoup(html, 'html.parser')
    
    try:  #시도해봐라
        content = soup.select('div.C4VMK > span')[0].text
    except:  #만약 본문내용이 없으면
        content = '' #빈칸
    try:
        date = soup.select('time._1o9PC.Nzb55')[0]['datetime'][:10]
    except: #만약 작성일자가 없으면
        date = ''

    tags = re.findall(r'#[^\s#,\\]+', content) 
    
    try:
        like = soup.select('a.zV_Nj > span')[0].text
    except:  #만약 좋아요수가 나타나지 않으면
        like = 0
    try : 
        place = soup.select('div > a.O4GIU')[0].text
    except:  #만약 장소가 안쓰여있으면
        place = ''
    
    data = [content, date, like, place, tags]  #데이터 리스트 만들어서 넣기
    return(data)  #함수 호출하면 이 데이터 리스트 나오게
```

```python
#함 해봐
mylist = get_content(driver)
mylist
```

```python
#다음 페이지로 넘어가는 함수
def move_next(driver):
    right = driver.find_element(BymCSS_SELECT, 'div.l8mY4.feth3')
    right.click()
    time.sleep(3)
```



---

```python
#실제 정리본
def insta_crawling(word, n):
    url = insta_searching(word)
    
    driver.get(url)
    time.sleep(3)
    
    select_first(driver)
    time.sleep(3)
    
    results = []
    
    for i in range(n):
        try:
            data = get_content(driver)
            results.append(data)
            move_next(driver)
            
        except:
            time.sleep(2)
            move_next(driver)
            
    return(results)


result_1 = insta_crawling('제주도맛집', 3) #알아서 옆으로 넘어가면서 데이터 정리됨
result_1

#result_1을 데이터 프레임으로 정리
result_df = pd.DataFrame(result_1)
result_df.columns = ['content', 'date', 'like','place','tags']
result_df.head()
```

![image-20220118005455816](Crawling_Instagram.assets/image-20220118005455816.png)

```python
#시간이 없어서 세 개 밖에 크롤링을 못해서 원래 있던 엑셀파일 불러와서 크롤링
jeju_insta_df = pd.DataFrame()
f_list = ['1_crawling_jejudoMatJip.xlsx', '1_crawling_jejudoGwanGwang.xlsx',
         '1_crawling_jejuMatJip.xlsx', '1_crawling_jejuYeoHang.xlsx']
for fname in f_list:
    fpath = './files/' + fname  #이 위치에 있는 거 읽어야 되니까
    temp = pd.read_excel(fpath)
    jeju_insta_df = jeju_insta_df.append(temp)
```

```python
jeju_insta_df.shape  #(12780,5)

#겹치는 내용 삭제
jeju_insta_df.drop_duplicates(subset = ['content'], inplace = True) #content같으면 drop
jeju_insta_df.shape   #(8369,5) << 본문 내용이 같은 것들 삭제 후 남은 

raw_total = jeju_insta_df.copy() #복사해놓고
raw_total.columns #Index(['content', 'date', 'like', 'place', 'tags'], dtype='object')
raw_total['tags']
```

![image-20220118010842114](Crawling_Instagram.assets/image-20220118010842114.png)

```python
#[] ㄸㅔ기
#(1)번 방법
tags_total = []
for tags in raw_total['tags']:
    tags_ilst = tags[2:-2].split("', '")
    
for tag in tags_list:
    tags_total.append(tag)
    
#(2)번 방법
raw_total['tags'][1].str[2:-2]
```

```python
#태그 하나당 얼마나 언급됐는지
from collections import Counter
tag_counts = Counter(tags_total)
tag_counts

#series로 만드는 방법(위에랑 똑같이)
pd.Series(tags_total).value_counts()
```

![image-20220118092204423](Crawling_Instagram.assets/image-20220118092204423.png)

```python
tag_counts.most_common(50)  #순위 50위   << 쓸데없는 속눈썹 이런 해시태그들 제거

STOPWORDS = ['#일상','#선팔', '#제주자연눈썹', '#제주눈썹문신', '#소통', '#맞팔', '#제주속눈썹', '#제주일상' ,'#제주도', '#jeju','#반영구','#제주살이', '#제주도민', '#여행스타그램', '#제주반영구' ,'#제주메이크업']
tag_total_selected = []
for tag in tags_total:
    if not tag in STOPWORDS:
        tag_total_selected.append(tag)
        
tag_total_selected = Counter(tag_total_selected)
tag_total_selected.most_common(50)  #이제 다시 확인
```

![image-20220118092748686](Crawling_Instagram.assets/image-20220118092748686.png)

```python
#시각화하기
import matplotlib.pyplot as plt
from matplotlib import rc
import sys  #에러났을 때 멈추는
import seaborn as sns

rc('font', family = 'Malgun Gothic')

tag_count_df = pd.DataFrame(tag_total_selected.most_common(50))
tag_count_df.columns = ['tags','count']
tag_count_df.head()

#블랭크가 있음 >> None으로
tag_count_df['tags'].replace('','None', inplace = True)
tag_count_df.dropna(subset = ['tags'], inplace = True)
tag_count_df
```

![image-20220118093208788](Crawling_Instagram.assets/image-20220118093208788.png)

```python
#barplot
plt.figure(figsize = (16,11))
sns.barplot(x = 'count', y = 'tags',
           data = tag_count_df)
plt.show()
```

![image-20220118093319997](Crawling_Instagram.assets/image-20220118093319997.png)

```python
#wordcloud

#pip install wordcloud
from wordcloud import WordCloud
import platform

if platform.system() == 'Windows':
    font_path = 'C:/Windows/Fonts/malgun.ttf'
    
wordcloud = WordCloud(font_path = font_path,
                     background_color = 'white',
                     max_words = 100,
                     relative_scaling = 0.3,
                     width = 800,
                     height = 400).generate_from_frequencies(tag_total_selected)
plt.figure(figsize = (18,10))
plt.imshow(wordcloud)
plt.axis('off')
```

![image-20220118093603629](Crawling_Instagram.assets/image-20220118093603629.png)